# Q1. Find the Frequency of Each Word in a Sentence
def word_frequency(sentence):
    counts = {}
    for word in sentence.split():
        word = word.lower()
        counts[word] = counts.get(word, 0) + 1
    return counts


# Q2. Find the Frequency of Each Character in a Word
def character_frequency(word):
    counts = {}
    for char in word:
        counts[char] = counts.get(char, 0) + 1
    return counts


# Q3. Find the First Non-Repeating Character in a Word
def first_non_repeating_char(word):
    counts = character_frequency(word)
    for char in word:
        if counts[char] == 1:
            return char
    return None


# Q4. Check Whether Two Strings Are Anagrams
def are_anagrams(s1, s2):
    return character_frequency(s1.replace(" ", "").lower()) == character_frequency(
        s2.replace(" ", "").lower()
    )


# Q5. Find the First Repeating Character in a String
def first_repeating_char(text):
    seen = set()
    for char in text:
        if char in seen:
            return char
        seen.add(char)
    return None


# Q6. Move All Zeros to the End of a List
def move_zeros_to_end(nums):
    non_zeros = [num for num in nums if num != 0]
    zeros = [num for num in nums if num == 0]
    return non_zeros + zeros


# Q7. Find the Second Highest Distinct Number in a List
def second_highest_distinct(nums):
    distinct = sorted(set(nums), reverse=True)
    return distinct[1] if len(distinct) >= 2 else None


# Q8. Remove Duplicates Without Changing the Original Order
def remove_duplicates(nums):
    result = []
    seen = set()
    for num in nums:
        if num not in seen:
            result.append(num)
            seen.add(num)
    return result


# Q9. Find the Missing Number from 1 to N
def missing_number(nums, n):
    return n * (n + 1) // 2 - sum(nums)


# Q10. Find Two Numbers Whose Sum Equals a Target
def two_sum_first_pair(nums, target):
    # Scan each second element from left to right; use the earliest matching prior element.
    seen = {}
    for num in nums:
        needed = target - num
        if needed in seen:
            return [seen[needed], num]
        if num not in seen:
            seen[num] = num
    return []


# Q11. Find the Number Closest to Zero
def closest_to_zero(nums):
    if not nums:
        return None
    return min(nums, key=lambda num: (abs(num), -num))


# Q12. Find Common Elements Between Two Lists
def common_elements(list1, list2):
    second = set(list2)
    result = []
    seen = set()
    for item in list1:
        if item in second and item not in seen:
            result.append(item)
            seen.add(item)
    return result


# Q13. Rotate a List to the Right by K Positions
def rotate_right(nums, k):
    if not nums:
        return []
    k %= len(nums)
    if k == 0:
        return nums[:]
    return nums[-k:] + nums[:-k]


# Q14. Find the Maximum Sum of Two Consecutive Elements
def max_consecutive_sum(nums):
    return max(nums[i] + nums[i + 1] for i in range(len(nums) - 1))


# Q15. Find All Pairs of Numbers Whose Sum Equals a Target
def all_unique_pairs(nums, target):
    pairs = set()
    seen = set()
    for num in nums:
        needed = target - num
        if needed in seen:
            pairs.add(tuple(sorted((num, needed))))
        seen.add(num)
    return [list(pair) for pair in sorted(pairs)]
