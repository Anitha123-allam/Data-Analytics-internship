# Import all 15 functions from solutions.py
from solutions import (
    word_frequency, character_frequency, first_non_repeating_char,
    are_anagrams, first_repeating_char, move_zeros_to_end,
    second_highest_distinct, remove_duplicates, missing_number,
    two_sum_first_pair, closest_to_zero, common_elements,
    rotate_right, max_consecutive_sum, all_unique_pairs
)


def show(question, example, extra):
    print(f"\n{question}")
    print("Given input:", example[0])
    print("Output:", example[1])
    print("Additional test:", extra[0])
    print("Additional output:", extra[1])


if __name__ == "__main__":
    show("Q1", ("python is easy and python is powerful",
                word_frequency("python is easy and python is powerful")),
         ("hello hello world", word_frequency("hello hello world")))

    show("Q2", ("banana", character_frequency("banana")),
         ("apple", character_frequency("apple")))

    show("Q3", ("swiss", first_non_repeating_char("swiss")),
         ("aabb", first_non_repeating_char("aabb")))

    show("Q4", (("listen", "silent"), are_anagrams("listen", "silent")),
         (("hello", "world"), are_anagrams("hello", "world")))

    show("Q5", ("programming", first_repeating_char("programming")),
         ("abcdef", first_repeating_char("abcdef")))

    show("Q6", ([0, 3, 0, 1, 2, 0, 4], move_zeros_to_end([0, 3, 0, 1, 2, 0, 4])),
         ([1, 0, 2], move_zeros_to_end([1, 0, 2])))

    show("Q7", ([10, 20, 40, 30, 40, 20],
                second_highest_distinct([10, 20, 40, 30, 40, 20])),
         ([5, 5, 5], second_highest_distinct([5, 5, 5])))

    show("Q8", ([4, 2, 4, 5, 2, 7, 5], remove_duplicates([4, 2, 4, 5, 2, 7, 5])),
         ([1, 1, 2, 3, 2], remove_duplicates([1, 1, 2, 3, 2])))

    show("Q9", (([1, 2, 4, 5, 6], 6), missing_number([1, 2, 4, 5, 6], 6)),
         (([1, 2, 3, 5], 5), missing_number([1, 2, 3, 5], 5)))

    show("Q10", (([2, 7, 11, 15], 9), two_sum_first_pair([2, 7, 11, 15], 9)),
         (([1, 4, 3, 2], 6), two_sum_first_pair([1, 4, 3, 2], 6)))

    show("Q11", ([-8, -3, 2, 5, -2], closest_to_zero([-8, -3, 2, 5, -2])),
         ([-4, -1, 3], closest_to_zero([-4, -1, 3])))

    show("Q12", (([1, 2, 3, 4, 5], [3, 4, 5, 6, 7]),
                 common_elements([1, 2, 3, 4, 5], [3, 4, 5, 6, 7])),
         (([4, 4, 2, 1], [4, 1]), common_elements([4, 4, 2, 1], [4, 1])))

    show("Q13", (([1, 2, 3, 4, 5], 2), rotate_right([1, 2, 3, 4, 5], 2)),
         (([1, 2, 3], 4), rotate_right([1, 2, 3], 4)))

    show("Q14", ([4, 7, 2, 9, 5], max_consecutive_sum([4, 7, 2, 9, 5])),
         ([1, 2, 10, 3], max_consecutive_sum([1, 2, 10, 3])))

    show("Q15", (([2, 4, 3, 5, 7, 8, 1], 9),
                 all_unique_pairs([2, 4, 3, 5, 7, 8, 1], 9)),
         (([1, 2, 3, 4, 5], 10), all_unique_pairs([1, 2, 3, 4, 5], 10)))
